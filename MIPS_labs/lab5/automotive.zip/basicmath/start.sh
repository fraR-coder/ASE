#!/bin/bash
#these paths must point to the installed gem5 folders
export PYTHONPATH=$PYTHONPATH:/opt/gem5
export PYTHONPATH=$PYTHONPATH:/opt/gem5/configs/common
export PYTHONPATH=$PYTHONPATH:/opt/gem5/configs
export PYTHONPATH=$PYTHONPATH:/opt/gem5/src/python
export PYTHONPATH=$PYTHONPATH:/opt/gem5/src/python/m5
export PYTHONPATH=$PYTHONPATH:/opt/gem5/src/sim

