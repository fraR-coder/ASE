/*----------------------------------------------------------------------------
 * Name:    sample.c
 * Purpose: to control led through EINT buttons and manage the bouncing effect
 *        	- key1 switches on the led at the left of the current led on, 
 *					- it implements a circular led effect. 	
  * Note(s): this version supports the LANDTIGER Emulator
 * Author: 	Paolo BERNARDI - PoliTO - last modified 15/12/2020
 *----------------------------------------------------------------------------
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2017 Politecnico di Torino. All rights reserved.
 *----------------------------------------------------------------------------*/
                  
#include <stdio.h>
#include "LPC17xx.H"                    /* LPC17xx definitions                */
#include "led/led.h"
#include "button_EXINT/button.h"
#include "timer/timer.h"
#include "RIT/RIT.h"
#include "joystick/joystick.h"

/* Led external variables from funct_led */
extern unsigned char led_value;					/* defined in funct_led								*/
#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif
/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void) {
  	
	SystemInit();  												/* System Initialization (i.e., PLL)  */
  //LED_init();                           /* LED Initialization                 */
  BUTTON_init();												/* BUTTON Initialization              */
	joystick_init();
	
	init_RIT(0x004C4B40);									/* RIT Initialization 50 msec   50ms*100MHz    */
	enable_RIT();													/* enable RIT to count 50ms				 */
	
	//timer(stop inplica disable)
	//1->interrupt 	2->	reset	3->stop
	
	//	init_timer(0, 0, 0, 7, 0x017D7840);  						1 secondo
	//init_timer(0, 0, 0, 3, 25000000 / 4);   //      per avere 4hz
	//enable_timer(0);
	
	//init_timer(1, 0, 0, 3, 25000000 / 5000);   //    per avere 5khz
	//enable_timer(1);
	
	
	//lampeggio 
	//init_timer(0, 0, 0, 1, 25000000 *0.9);   //      per avere 0.9s spento qui accendo led
	//init_timer(0, 0, 1, 3, 25000000 *2.4);   //      per avere 1.3s acceso  qui spengo led
	
	LPC_SC->PCON |= 0x1;									/* power-down	mode										*/
	LPC_SC->PCON &= ~(0x2);						
		
  while (1) {                           /* Loop forever                       */	
//		__ASM("wfi");
  }
	


}

void update_time(void)
{
		//char a[200];
	
		/*sprintf(a,"  Age: %02d:%02d:%02d",hours,minutes,seconds);
			if (seconds > 59)
		{
			seconds = 0;

			if (minutes > 59)
			{
				minutes = 0;

				hours++;
			}
			minutes++;
		}
		seconds++;
		time = 1;
		*/
}
